
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-primery card-outline md-4">
        <div class="card-header">
            <div class="card-title"> Ctegory</div>
        </div>
        <div class="container">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
        </div>

    </div>
    <form method="post" action="<?php echo e(route('admin.category.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="mb-3">
                <label for="name"> Nmae</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                <div class="text-danger">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="mb-3">
                <label for="slug">Slug</label>
                <input type="text" class="form-control" name="slug" value="<?php echo e(old('slug')); ?>">
                <div class="text-danger">
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#cat').on('submit', function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            $.ajax({

                url: $(this).attr('action'),
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    alert('category added successfully');
                    console.log(response);
                },
                error: function(xhr) {
                    alert('error');
                    console.log(xhr.responseText);
                }


            });

        });
    });
</script>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anily\Desktop\varsha2025\ecommvar\resources\views/admin/category/create.blade.php ENDPATH**/ ?>