

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Shopping Cart</h2>
    <?php if($cartItems->count() > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product->name); ?></td>
                <td>$<?php echo e(number_format($item->price, 2)); ?></td>
                <td>
                    <input type="number" value="<?php echo e($item->quantity); ?>" min="1" class="cart-quantity" data-id="<?php echo e($item->product_id); ?>">
                </td>
                <td>$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                <td>
                    <button class="btn btn-danger remove-from-cart" data-id="<?php echo e($item->product_id); ?>">Remove</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Proceed to Checkout</a>
    <?php else: ?>
    <p>Your cart is empty.</p>
    <?php endif; ?>
</div>

<script>
    document.querySelectorAll(".remove-from-cart").forEach(button => {
        button.addEventListener("click", function() {
            let productId = this.dataset.id;

            fetch("<?php echo e(route('cart.remove')); ?>", {
                    method: "POST",
                    headers: {
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        product_id: productId
                    }),
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    location.reload();
                });
        });
    });

    document.querySelectorAll(".cart-quantity").forEach(input => {
        input.addEventListener("change", function() {
            let productId = this.dataset.id;
            let quantity = this.value;

            fetch("<?php echo e(route('cart.update')); ?>", {
                    method: "POST",
                    headers: {
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        product_id: productId,
                        quantity: quantity
                    }),
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    location.reload();
                });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anily\Desktop\varsha2025\ecommvar\resources\views/cart/view.blade.php ENDPATH**/ ?>