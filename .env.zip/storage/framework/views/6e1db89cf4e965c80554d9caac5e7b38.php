
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Category</h3>
            <div class="card-tools">
                <a class="btn btn-secondry"> Back</a>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body p-0">
            <table class="table">
                <thead>
                    <tr>
                        <th>id</th>

                        <th>Name</th>
                        <th>Category</th>
                        <th>Product</th>

                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->category ? $category->category->name : 'N/A'); ?></td>
                        <td><?php echo e($category->product ? $category->product->name : 'N/A'); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.productcategory.edit', $category->id)); ?>" class="btn btn-sm btn-primary">Edit</a>

                            <form action="<?php echo e(route('admin.productcategory.destroy', $category->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this category?')">Delete</button>
                            </form>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anily\Desktop\varsha2025\ecommvar\resources\views/admin/productcategory/index.blade.php ENDPATH**/ ?>