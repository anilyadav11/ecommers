

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>My Orders</h2>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-3">
        <div class="card-header">
            <strong>Order #<?php echo e($order->id); ?></strong> - <?php echo e($order->status); ?>

        </div>
        <div class="card-body">
            <p>Total: $<?php echo e(number_format($order->total_price, 2)); ?></p>
            <ul>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($item->product->name); ?> (x<?php echo e($item->quantity); ?>) - $<?php echo e(number_format($item->price, 2)); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anily\Desktop\varsha2025\ecommvar\resources\views/orders/index.blade.php ENDPATH**/ ?>