@include('layouts.header')
<main>@yield('content')</main>
@include('layouts.footer')