<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports World</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- OWL Car -->
    <link rel="stylesheet" href="{{asset('newAdmin/css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset('newAdmin/css/owl.theme.default.min.css')}}">
    <!-- Showmore css -->
    <link rel="stylesheet" href="{{asset('newAdmin/css/showMoreItems-theme.min.css')}}">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset('newAdmin/css/bootstrap.min.css')}}">
    <!-- Theme CSS -->
    <link rel="stylesheet" href="{{asset('newAdmin/css/style.css')}}">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-md navbar-light">
        <button class="navbar-toggler ml-auto mb-2 bg-light" type="button" data-toggle="collapse" data-target="#mynav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynav">
            <div class="container-fluid">
                <div class="row">
                    <!-- Sidebar -->
                    <div class="col-lg-2 col-md-4 fixed-top sidebar">
                        <a href="index.html"
                            class="navbar-brand text-light d-block mx-auto text-center py-3 mb-4 bottom-border"><img
                                src="./img/logo.png" class="img-fluid" width="200px" alt="logo"></a>
                        <div class="bottom-border pb-3">
                            <img src="./img/profile.jpg" alt="" width="60" class="rounded-circle">
                            <a href="#" class="text-light">Mostakimul</a>
                        </div>
                        <ul class="navbar-nav flex-column mt-5">
                            <li class="nav-item">
                                <a href="dashboard.html" class="nav-link text-light p-3 mb-2 sidebar-link current">
                                    <i class="fa fa-home text-light fa-lg mr-3"></i>Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="allproduct.html" class="nav-link text-light p-3 mb-2 sidebar-link">
                                    <i class="fa fa-database text-light fa-lg mr-3"></i>All Product
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="addproduct.html" class="nav-link text-light p-3 mb-2 sidebar-link">
                                    <i class="fa fa-plus-circle text-light fa-lg mr-3"></i>Add Product
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="editproduct.html" class="nav-link text-light p-3 mb-2 sidebar-link">
                                    <i class="fa fa-pencil-square-o text-light fa-lg mr-3"></i>Edit Product
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="removeproduct.html" class="nav-link text-light p-3 mb-2 sidebar-link">
                                    <i class="fa fa-trash text-light fa-lg mr-3"></i>Remove Product
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link text-light p-3 mb-2 sidebar-link">
                                    <i class="fa fa-cogs text-light fa-lg mr-3"></i>Settings
                                </a>
                            </li>
                        </ul>
                    </div>

                    <!-- Top Nav -->
                    <div class="col-lg-10 col-md-8 ml-auto fixed-top cstm-header align-items-center top-nav">
                        <div class="row">
                            <div class="col-lg-4 col-md-8 d-flex justify-content-center align-items-center pl-5">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item active">
                                        <a class="nav-link mx-2 text-light" href="index.html">Home <span
                                                class="sr-only">(current)</span></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link mx-2 text-light" href="{{route('orders.view')}}">Order</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link mx-2 text-light" href="dashboard.html">Dashboard</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-lg-6 d-none d-lg-block">
                                <form class="form-inline">
                                    <input class="form-control mx-2 my-2" type="search" placeholder="Search"
                                        aria-label="Search">
                                    <button class="btn btn-light" type="submit"><i class="fa fa-search"
                                            aria-hidden="true"></i>
                                    </button>
                                </form>

                            </div>
                            <div class="col-md-4 col-lg-2 mt-2 justify-content-end align-items-center">
                                <button class="btn btn-outline-light mx-2" data-toggle="modal" data-target="#logout"><i
                                        class="fa fa-sign-out" aria-hidden="true"></i>
                                    Logout</button>
                            </div>
                        </div>
                    </div>
                    <!-- Top Nav Ends -->
                </div>
            </div>
        </div>

    </nav>

    <!-- Logout Modal -->
    <div class="modal fade" id="logout">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-dark text-light">
                    <h5 class="modal-title">Do You Really Want to Leave?</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <!-- <div class="modal-body">
                    <h5>Press Logout to leave</h5>
                </div> -->
                <div class="modal-footer bg-dark">
                    <button type="button" class="btn btn-light">Stay Here</button>
                    <button type="button" class="btn btn-danger">Logout</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Logout Modal Ends -->

    <!-- Cards -->
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-10 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3 mb-5">
                        <div class="col-sm-6 col-xl-3 p-2">
                            <div class="card cstm-card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <i class="fa fa-shopping-cart fa-4x text-danger"></i>
                                        <div class="text-right text-secondary">
                                            <h5>Sales</h5>
                                            <h3>$135,000</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer text-secondary">
                                    <i class="fa fa-refresh mr-3"></i>
                                    <span>Update Now</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-3 p-2">
                            <div class="card cstm-card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <i class="fa fa-money fa-4x text-success"></i>
                                        <div class="text-right text-secondary">
                                            <h5>Expenses</h5>
                                            <h3>$40,000</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer text-secondary">
                                    <i class="fa fa-refresh mr-3"></i>
                                    <span>Update Now</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-3 p-2">
                            <div class="card cstm-card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <i class="fa fa-users fa-4x text-info"></i>
                                        <div class="text-right text-secondary">
                                            <h5>Users</h5>
                                            <h3>10,000</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer text-secondary">
                                    <i class="fa fa-refresh mr-3"></i>
                                    <span>Update Now</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-3 p-2">
                            <div class="card cstm-card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <i class="fa fa-line-chart fa-4x text-danger"></i>
                                        <div class="text-right text-secondary">
                                            <h5>Visitors</h5>
                                            <h3>20,000</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer text-secondary">
                                    <i class="fa fa-refresh mr-3"></i>
                                    <span>Update Now</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Cards Ends -->

    <!-- Table Start -->
    <section>
        <div class="container-fluid">
            <div class="row mb-5">
                <div class="col-lg-10 col-md-8 ml-auto">
                    <div class="row align-items-center">
                        <!-- First Table -->
                        <div class="col-12 col-xl-6 mb-4 mb-xl-0">
                            <h4 class="text-muted text-center mb-3">All Orders</h4>
                            <table class="table bg-light table-hover table-striped  text-center display" id="allorders">
                                <thead>
                                    <tr class="text-muted">
                                        <th>#SL</th>
                                        <th>Order No.</th>
                                        <th>Product Name</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>1</th>
                                        <td>pr001</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><span class="badge badge-success w-60 py-2">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <th>2</th>
                                        <td>pr002</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><span class="badge badge-success w-60 py-2">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <th>3</th>
                                        <td>pr003</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><span class="badge badge-success w-60 py-2">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <th>4</th>
                                        <td>pr004</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><span class="badge badge-success w-60 py-2">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <th>5</th>
                                        <td>pr005</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><span class="badge badge-success w-60 py-2">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <th>6</th>
                                        <td>pr006</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><span class="badge badge-success w-60 py-2">Completed</span></td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                        <!-- Second Table -->
                        <div class="col-12 col-xl-6">
                            <h4 class="text-muted text-center mb-3">Recent Orders</h4>
                            <table class="table table-hover bg-light table-striped text-center display"
                                id="recentorders">
                                <thead>
                                    <tr class="text-muted">
                                        <th>#SL</th>
                                        <th>Order No.</th>
                                        <th>Product Name</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>1</th>
                                        <td>pr009</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><button type="button" class="btn btn-success btn-sm">Approved</button></td>
                                    </tr>
                                    <tr>
                                        <th>2</th>
                                        <td>pr0010</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><button type="button" class="btn btn-danger btn-sm">Pending</button></td>
                                    </tr>
                                    <tr>
                                        <th>3</th>
                                        <td>pr0011</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><button type="button" class="btn btn-danger btn-sm">Pending</button></td>
                                    </tr>
                                    <tr>
                                        <th>4</th>
                                        <td>pr0012</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><button type="button" class="btn btn-success btn-sm">Approved</button></td>
                                    </tr>
                                    <tr>
                                        <th>5</th>
                                        <td>pr0013</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><button type="button" class="btn btn-danger btn-sm">Pending</button></td>
                                    </tr>
                                    <tr>
                                        <th>6</th>
                                        <td>pr0014</td>
                                        <td>Black Shoe</td>
                                        <td>$99</td>
                                        <td><button type="button" class="btn btn-success btn-sm">Approved</button></td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Table End -->

    <!-- Bootstrap js -->
    <script type="text/javascript" src="{{asset('newAdmin/js/jquery.js')}}"></script>
    <script type="text/javascript" src="{{asset('newAdmin/js/popper.js')}}"></script>
    <!-- OWL Car -->
    <script src="{{asset('newAdmin/js/owl.carousel.min.js')}}"></script>
    <!-- Show More js -->
    <script src="{{asset('newAdmin/js/showMoreItems.min.js')}}"></script>

    <script type="text/javascript" src="{{asset('newAdmin/js/bootstrap.min.js')}}"></script>
    <!-- Theme js -->
    <script type="text/javascript" src="{{asset('newAdmin/js/main.js')}}"></script>
</body>

</html>