@extends('layouts.app')

@section('content')
<div class="container">
    <h2>My Orders</h2>

    @foreach($orders as $order)
    <div class="card mb-3">
        <div class="card-header">
            <strong>Order #{{ $order->id }}</strong> - {{ $order->status }}
        </div>
        <div class="card-body">
            <p>Total: ${{ number_format($order->total_price, 2) }}</p>
            <ul>
                @foreach($order->items as $item)
                <li>{{ $item->product->name }} (x{{ $item->quantity }}) - ${{ number_format($item->price, 2) }}</li>
                @endforeach
            </ul>
        </div>
    </div>
    @endforeach
</div>
@endsection