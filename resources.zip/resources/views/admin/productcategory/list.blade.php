@extends('admin.layouts.app')
@section('content')
<div class="col-md-12">
    <div class="card card-primery card-outline mb-4">
        <div class="card-header">
            <div class="card-title">Product Category List</div>

        </div>
        <table>
            <div class="card-body">
                
            </div>
        </table>
    </div>
</div>
@endsection