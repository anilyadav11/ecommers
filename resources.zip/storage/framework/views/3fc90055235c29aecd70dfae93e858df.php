
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-primery card-outline mb-4">
        <div class="card-header">
            <div class="card-title"> Product Caregory</div>
        </div>
        <div class="container-fluid">
            <?php if(session('success')): ?>
            <div class="alert alert-success">

                <?php echo e(session('success')); ?>


            </div>
            <?php endif; ?>
        </div>
        <form method="post" action="<?php echo e(route('admin.productcategory.store')); ?>" id="productcategory" enctype="multipart/form-data">
            <div class="card-body">
                <div class="mb-4">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="mb-4">
                    <label for="validationCustom04" class="form-label">Product Id</label>
                    <select class="form-select" id="validationCustom04" required name="product_id ">
                        <option selected disabled value="">Choose...</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="invalid-feedback">Please select a valid state.</div>

                </div>
                <div class="mb-4">
                    <label for="validationCustom04" class="form-label">Category Id</label>
                    <select class="form-select" id="validationCustom04" required name="product_id ">
                        <option selected disabled value="">Choose...</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categories->id); ?>"><?php echo e($categories->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="invalid-feedback">Please select a valid state.</div>

                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#productcategory').on('submit', function(e) {
            e.preventDefault();
            let formData = new FormData(this);
            $.ajax({
                url: $(this).attr('action'),
                method: 'POST',
                data: formData,
                processData: false,
                containtType: false,
                header: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    alert('added successfully');
                    console.log(response);
                },
                error: function(xhr) {
                    alert('fail');
                    console.log(xhr.responseText);
                }

            })

        })
    });
</script>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anily\Desktop\varsha2025\ecommvar\resources\views/admin/productcategory/create.blade.php ENDPATH**/ ?>